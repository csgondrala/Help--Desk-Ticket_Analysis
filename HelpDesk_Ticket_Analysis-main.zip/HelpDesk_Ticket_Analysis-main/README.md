# Help Desk Ticket Analysis (SQL + Power BI)

This project analyzes IT support ticket data to uncover insights about SLA performance, agent productivity, and support trends using SQL and Power BI.

##  Overview

A simulated IT help desk dataset was cleaned, analyzed using SQL (SQLite), and visualized in Power BI. The final dashboard provides KPIs and trends that reflect how real support teams track SLA compliance and resolve tickets.

##  Tools Used

- **SQLite / DB Browser** – Data cleaning and querying
- **Power BI Desktop** – Interactive dashboard and visualizations
- **CSV** – Output formatting and structure

##  Files Included

| File                                      | Description                          |
|-------------------------------------------|--------------------------------------|
| `HelpDesk_Ticket_Analysis_Dashboard.pdf`  | Final Power BI dashboard export      |
| `sla_summary.csv`                         | SLA met vs. violated summary         |
| `agent_performance.csv`                   | Avg resolution time per agent        |
| `issue_type_breakdown.csv`                | Most common support issue types      |
| `ticket_volume_by_day.csv`                | Daily ticket submission volume       |
| `HelpDesk_Ticket_Analysis.pbix`           | Source Power BI file                 |

##  Dashboard Highlights

-  SLA Compliance Breakdown (Met vs. Violated)
- Average Resolution Time per Agent
-  Most Common Support Issue Types
-  Ticket Volume Trends Over Time
-  KPI Cards: Total Tickets, SLA Met %, Avg Time

##  Key SQL Concepts Used

- `JOIN` statements
- `CASE` logic for SLA status
- `JULIANDAY()` for time difference calculation
- `GROUP BY`, `ORDER BY` for aggregation

##  Project Purpose

To simulate a real-world IT support analytics scenario and showcase technical skills in:
- Data analysis with SQL
- Dashboard design with Power BI
- KPI reporting for service desk environments

##  Outcome

This project demonstrates the ability to turn raw IT support data into actionable insights and present it in a clean, professional dashboard — ideal for help desk, IT support, and analyst roles.

---


